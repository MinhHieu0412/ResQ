import React from 'react'

const ManagerDashboard = () => {
  return (
    <div>ManagerDashboard</div>
  )
}

export default ManagerDashboard