import React from "react";

const StaffDashboard = () => {
  return <div>StaffDashboard</div>;
};

export default StaffDashboard;
