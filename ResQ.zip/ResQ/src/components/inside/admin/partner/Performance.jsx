import React from "react";

const Performance = () => {
  return <div>Performance</div>;
};

export default Performance;
