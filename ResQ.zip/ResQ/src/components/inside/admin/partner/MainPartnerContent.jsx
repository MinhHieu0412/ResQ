import React from "react";

const MainPartnerContent = () => {
  return <div>MainPartnerContent</div>;
};

export default MainPartnerContent;
