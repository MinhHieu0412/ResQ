import React from "react";

const RescueCalls = () => {
  return <div>RescueCalls</div>;
};

export default RescueCalls;
