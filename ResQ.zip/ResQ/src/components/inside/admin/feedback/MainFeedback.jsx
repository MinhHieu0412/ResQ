import React from "react";

const MainFeedback = () => {
  return <div>MainFeedback</div>;
};

export default MainFeedback;
