import React from "react";

const MainServices = () => {
  return <div>MainServices</div>;
};

export default MainServices;
