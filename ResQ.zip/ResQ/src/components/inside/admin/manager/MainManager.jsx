import React from "react";

const MainManager = () => {
  return <div>MainManager</div>;
};

export default MainManager;
