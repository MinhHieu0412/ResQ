import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';


const ChatBox = () => {
  const [userId, setUserId] = useState(null);
  const [conversationId, setConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [messageInput, setMessageInput] = useState('');
  const messageEndRef = useRef(null);

  const token = localStorage.getItem('token');
  const authHeader = {
    headers: {
      Authorization: `Bearer ${token}`
    }
  };

  useEffect(() => {
    const id = parseInt(localStorage.getItem('userId'));
    setUserId(id);

    const fetchConversation = async () => {
      try {
        const res = await axios.get(
          `http://localhost:9090/api/messages/conversation/user/${id}`,
          authHeader
        );
        setConversationId(res.data.conversationId);
      } catch (error) {
        console.error('❌ Error getting conversation:', error);
      }
    };

    if (id && token) {
      fetchConversation();
    }
  }, [token]);

  useEffect(() => {
    if (!conversationId || !token) return;

    const fetchMessages = async () => {
      try {
        const res = await axios.get(
          `http://localhost:9090/api/messages/${conversationId}`,
          authHeader
        );
        setMessages(Array.isArray(res.data) ? res.data : []);
      } catch (error) {
        console.error('❌ Error fetching messages:', error);
      }
    };

    fetchMessages();
  }, [conversationId, token]);

  useEffect(() => {
    if (messageEndRef.current) {
      messageEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleInputChange = (e) => {
    setMessageInput(e.target.value);
  };

  return (
    <div className="flex h-screen bg-white font-sans">
      {/* Sidebar bên trái giả lập */}
      <div className="w-72 border-r bg-[#FAFAFA] p-4">
        <input
          type="text"
          placeholder="Search"
          className="w-full px-4 py-2 border rounded-lg text-sm mb-4 focus:outline-none"
        />
        {[...Array(4)].map((_, i) => (
          <div key={i} className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-gray-100">
            <img src="/avatar.png" alt="avatar" className="w-9 h-9 rounded-full" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-blue-700">Tran Thi A</p>
              <p className="text-xs text-gray-500">Ok</p>
            </div>
            <p className="text-xs text-gray-400">10:25PM</p>
          </div>
        ))}
      </div>

      {/* Khung nội dung chính */}
      <div className="flex-1 flex flex-col bg-white">
        {/* Header */}
        <div className="flex items-center gap-3 border-b px-6 py-4">
          <img src="/avatar.png" alt="avatar" className="w-10 h-10 rounded-full" />
          <div>
            <p className="font-bold text-blue-800 text-lg">Tran Thi A</p>
            <p className="text-sm text-green-500">● Đang hoạt động</p>
          </div>
        </div>

        {/* Tin nhắn */}
        <div className="flex-1 px-6 py-6 overflow-auto space-y-4">
          {messages.map((msg, index) => {
            const isOwn = msg.senderId === userId;
            return (
              <div key={index} className={`flex ${isOwn ? 'justify-end' : 'justify-start'} items-start`}>
                {!isOwn && (
                  <img
                    src="/avatar.png"
                    alt="avatar"
                    className="w-8 h-8 rounded-full mr-2 self-end"
                  />
                )}
                <div
                  className={`rounded-2xl px-5 py-3 max-w-sm text-sm shadow-sm ${
                    isOwn
                      ? 'bg-blue-500 text-white rounded-br-md'
                      : 'bg-gray-100 text-black rounded-bl-md'
                  }`}
                >
                  <p>{msg.content}</p>
                  <p className="text-[11px] mt-1 text-right">
                    {msg.createdAt &&
                      new Date(msg.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={messageEndRef} />
        </div>

        {/* Input nhắn tin */}
        <div className="px-6 py-4 border-t bg-white flex items-center">
          <input
            type="text"
            placeholder="Viết tin nhắn ở đây"
            className="flex-1 border rounded-full px-5 py-3 text-sm border-gray-300 focus:outline-none"
            value={messageInput}
            onChange={handleInputChange}
          />
          <button className="ml-3 bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-full">
            <svg className="w-5 h-5 transform rotate-45" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2.94 2.94a1.5 1.5 0 012.12 0L17.06 15.06a1.5 1.5 0 01-2.12 2.12L2.94 5.06a1.5 1.5 0 010-2.12z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatBox;
