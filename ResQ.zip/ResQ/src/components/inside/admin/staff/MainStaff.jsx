import React from "react";

const MainStaff = () => {
  return <div>MainStaff</div>;
};

export default MainStaff;
