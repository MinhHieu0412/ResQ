import React from "react";

const MainRequestResQ = () => {
  return <div>MainRequestResQ</div>;
};

export default MainRequestResQ;
