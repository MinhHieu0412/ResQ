import React from "react";

const MainCustomer = () => {
  return <div>MainCustomer</div>;
};

export default MainCustomer;
