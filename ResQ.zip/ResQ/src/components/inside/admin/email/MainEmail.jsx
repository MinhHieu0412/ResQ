import React from "react";

const MainEmail = () => {
  return <div>MainEmail</div>;
};

export default MainEmail;
