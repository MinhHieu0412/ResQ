// components/DashboardContent.jsx
const DashboardContent = () => {
  return <div>Đây là nội dung Dashboard</div>;
};

export default DashboardContent;
