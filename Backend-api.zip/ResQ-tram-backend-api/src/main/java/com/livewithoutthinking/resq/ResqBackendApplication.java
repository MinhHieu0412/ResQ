package com.livewithoutthinking.resq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResqBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResqBackendApplication.class, args);
	}

}
